"""Sentiment prediction API package."""
